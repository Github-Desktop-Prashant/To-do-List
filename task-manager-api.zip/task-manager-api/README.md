# Task Manager API

## Endpoints

- `GET /tasks`: Retrieve a list of all tasks.
- `GET /tasks/:id`: Retrieve a specific task by ID.
- `POST /tasks`: Create a new task.
- `PUT /tasks/:id`: Update an existing task by ID.
- `DELETE /tasks/:id`: Delete a task by ID.

## Example Requests and Responses

### Create a Task

- **Request**:

POST /tasks
{
"title": "New Task",
"description": "This is a new task"
}

- **Response**:
{
"id": 1,
"title": "New Task",
"description": "This is a new task"
}


### Get All Tasks

- **Request**:

GET /tasks

- **Response**:

[
{
"id": 1,
"title": "New Task",
"description": "This is a new task"
}
]

// Add similar examples for other endpoints.
